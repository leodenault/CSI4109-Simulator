The GraphStream library was used to render the graph to the screen.
The library is licensed under the CeCILL-C and the GNU Lesser General
Public Licenses.

The GraphStream website can be found at: http://graphstream-project.org/

The CeCILL-C license is hosted at: http://www.cecill.info/licences/Licence_CeCILL-C_V1-en.html
The GNU Lesser General Public License is hosted at:  https://www.gnu.org/licenses/lgpl.html
